package com.pj2.pacman;

class Hero extends Creature {
    int speed = 2;
    int cur_dir;
    boolean moving;

    Hero(int x, int y) {
        super(x, y);
        moving = false;
        setImage();
    }

    @Override
    void setImage() {
    }

    @Override
    void backToLife() {
        super.backToLife();
        cur_dir = DOWN;
        moving = false;
        setImage();
    }

    @Override
    void move() {
        if (sleep) return;
        if (canMove(direction, x, y)) {
            cur_dir = direction;
            direction = -1;
            moving = true;
            setImage();
            /**Enemy en = new Enemy(9 * Map.side, 9 * Map.side, 1, Enemy.slowSpeed);
            Pacman.pa.getChildren().addAll(en.icon);
            en.animation.play();*/
        }
        if (canMove(cur_dir, x, y)) {
            changePos(speed, cur_dir);
        }
        else {
            moving = false;
            setImage();
        }
        Pacman.judge();
        Pacman.eat();
    }

}
