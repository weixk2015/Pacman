package com.pj2.pacman;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Scanner;

class Map {
    Cell[][] background;
    final static int side = 32;
    static int width;
    static int height;
    //分别代表：上，右，下，左，左上，右上，右下，左下，左，上，右，下
    private final int[] dX = {0, 1, 0, -1, -1, 1, 1, -1, -1, 0, 1, 0};
    private final int[] dY = {-1, 0, 1, 0, -1, -1, 1, 1, 0, -1, 0, 1};

    void loadMap(InputStream inputStream) {
        try {
            Scanner input = new Scanner(inputStream);
            height = input.nextInt();
            width = input.nextInt();
            background = new Cell[height][width];
            Enemy.enemies.clear();
            Bean.beans.clear();
            for (int i = 0; i < height; i++) {
                for (int j = 0; j < width; j++) {
                    int thisType = input.nextInt();
                    background[i][j] = new Cell(side * j, side * i, (thisType == 1 ? 1 : 0));
                    if (thisType == 2) new Bean(side * j, side * i, 2);
                    if (thisType == 3) new Bean(side * j, side * i, 3);
                }
            }
            Pacman.hero = new Hero(input.nextInt() * Map.side, input.nextInt() * Map.side);
            int enemySize = input.nextInt();
            for (int i = 0; i < enemySize; i++) {
                new Enemy(input.nextInt() * side, input.nextInt() * side, input.nextInt());
            }
            input.close();
            loadImage();
        } catch (Exception ex) {
            Pacman.error();
        }
    }

    void loadImage() {
        String type1;
        int type2;
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                type1 = "";
                type2 = 0;
                if (background[i][j].type == 1) {
                    for (int d = 0; d < 4; d++) {
                        type1 += background[outOfIndex(i + dY[d], 1)][outOfIndex(j + dX[d], 0)].type;
                    }
                    for (int d = 4; d < 8; d++) {
                        type2 += Math.pow(10, 7 - d) * background[outOfIndex(i + dY[d], 1)][outOfIndex(j + dX[d], 0)].type *
                                background[outOfIndex(i + dY[d + 4], 1)][outOfIndex(j + dX[d + 4], 0)].type *
                                background[outOfIndex(i + dY[d - 4], 1)][outOfIndex(j + dX[d - 4], 0)].type;
                    }
                    background[i][j].setImageOfWall(type1, type2);
                } else background[i][j].setImageOfWall("road", 0);
            }
        }
    }

    private int outOfIndex(int pos, int hv) {
        if (pos < 0 || pos >= (hv == 0 ? width: height))
            pos -= (int)Math.signum(pos) * (hv == 0 ? width: height);
        return pos;
    }
}
