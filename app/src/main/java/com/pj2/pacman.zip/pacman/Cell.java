package com.pj2.pacman;

class Cell {
    static final int ROAD = 0;
    static final int WALL = 1;
    int x;
    int y;
    int type;
    //Image image;

    Cell(int x, int y, int type) {
        this.x = x;
        this.y = y;
        this.type = type;
    }

    void setImageOfWall(String tpye1, int type2) {
        //待完成
    }

    static int typeOf(int x, int y) {
        //找到含点(x,y)的Cell，返回地形
        return WALL;
    }

}
