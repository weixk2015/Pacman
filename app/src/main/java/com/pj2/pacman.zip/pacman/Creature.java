package com.pj2.pacman;

abstract class Creature {
    int x;
    int y;
    int x_birth;
    int y_birth;
    int direction;
    boolean sleep;
    //Image[] icon; //9个image实现地图穿越时的生物图标显示
    private int[] iconX;
    private int[] iconY;
    
    //direction array
    //0-8分别表示：上，右，下，左， 左上，右上，右下，左下，原地
    final static int UP = 0;
    final static int RIGHT = 1;
    final static int DOWN = 2;
    final static int LEFT = 3;
    final static int[] DIR_X = {0, 1, 0, -1, -1, 1, 1, -1, 0};
    final static int[] DIR_Y = {-1, 0, 1, 0, -1, -1, 1, 1, 0};
    //0-3分别表示：左上角上，右上角右，右下角下，左下角左
    private final static int[] DIR_X1 = {0, Map.side, Map.side - 1, -1};
    private final static int[] DIR_Y1 = {-1, 0, Map.side, Map.side - 1};
    //0-3分别表示：右上角上，右下角右，左下角下，左上角左
    private final static int[] DIR_X2 = {Map.side - 1, Map.side, 0, -1};
    private final static int[] DIR_Y2 = {-1, Map.side - 1, Map.side, 0};

    Creature(int x, int y) {
        x_birth = x;
        y_birth = y;
        setPos(x, y);
        sleep = true;
        direction = DOWN; //起始向下
        //icon = new Image[9];
        iconX = new int[9];
        iconY = new int[9];
        for (int i = 0; i < 9; i++) {
            iconX[i] = DIR_X[i] * Map.side * Map.width;
            iconY[i] = DIR_Y[i] * Map.side * Map.height;
            //icon[i] = new Image();
        }
    }

    //移动
    abstract void move();

    //更新图片
    abstract void setImage();

    //复活
    void backToLife() {
        setPos(x_birth, y_birth);
        sleep = true;
        direction = DOWN;
    }

    //判断是否可动
    boolean canMove(int dir, int x, int y) {
        if (dir == -1) return false;
        int xOnDir1 = outOfIndex(x + DIR_X1[dir], true);
        int yOnDir1 = outOfIndex(y + DIR_Y1[dir], false);
        int xOnDir2 = outOfIndex(x + DIR_X2[dir], true);
        int yOnDir2 = outOfIndex(y + DIR_Y2[dir], false);
        boolean canMove1 = (Cell.typeOf(xOnDir1, yOnDir1) == 0);
        boolean canMove2 = (Cell.typeOf(xOnDir2, yOnDir2) == 0);
        return (canMove1 && canMove2);
    }

    //越界判断
    private int outOfIndex(int pos, boolean hv) { //true for x, false for y
        if (pos < 0 || pos >= Map.side * (hv? Map.width: Map.height))
            pos -= (int)Math.signum(pos) * Map.side * (hv? Map.width: Map.height);
        return pos;
    }

    private void setPos(int x, int y) {
        this.x = x;
        this.y = y;
        for (int i = 0; i < 9; i++) {
            //icon[i].setX(x + iconX[i]);
            //icon[i].setY(y + iconY[i]);
        }
    }
    
    void changePos(int speed, int dir) {
        x = outOfIndex(x + speed * DIR_X[dir], true);
        y = outOfIndex(y + speed * DIR_Y[dir], false);
        for (int i = 0; i < 9; i++) {
            //icon[i].setX(x + iconX[i]);
            //icon[i].setY(y + iconY[i]);
        }
    }
    
}
