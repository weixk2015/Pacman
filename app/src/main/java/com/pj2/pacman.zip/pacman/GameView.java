package com.pj2.pacman;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.View;
import android.graphics.BitmapFactory;
import android.view.WindowManager;

import java.io.IOException;

/**
 * Created by xk on 2016/12/24.
 */

public class GameView extends View implements Runnable {
    private Map map = Pacman.map;
    private int Ox = 0;
    private int Oy = 0;
    private Hero hero = Pacman.hero;
    // 声明屏幕的宽高
    private int screenW , screenH;
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        //加载资源图片图片
        Bitmap heroBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.p_hero1);

        canvas.drawBitmap(heroBitmap,screenW/2, screenH/2, null);
    }
    public GameView(Context context) throws IOException {
        super(context);

        WindowManager wm = (WindowManager) getContext()
                .getSystemService(Context.WINDOW_SERVICE);
        screenW = wm.getDefaultDisplay().getWidth();
        screenH = wm.getDefaultDisplay().getHeight();
        Pacman.newGame(this);
        //启动线程
        new Thread(this).start();
    }

    public void myDraw(){

    }

    @Override
    public void run() {
        while (true) {
            long start = System.currentTimeMillis();
            myDraw();
            logic();
            this.postInvalidate();
            long end = System.currentTimeMillis();
            try {
                if (end - start < 50) {
                    Thread.sleep(50 - (end - start));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }



    /**
     * 触屏事件监听
     */
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        int handX = 400;
        float dx = x- handX;
        int handY = 200;
        float dy = y- handY;
        if (dx-dy>0){
            hero.direction = dx+dy>0?Creature.UP:Creature.LEFT;
        }else {
            hero.direction = dx+dy>0?Creature.RIGHT:Creature.DOWN;
        }
        return true;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return super.onKeyDown(keyCode, event);
    }
    /**
     * 游戏逻辑
     */
    private void logic() {
        hero.move();


    }
}
