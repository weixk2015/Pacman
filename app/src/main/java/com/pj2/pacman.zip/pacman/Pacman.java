package com.pj2.pacman;

import android.view.View;

class Pacman {
    static Map map;
    static Hero hero;
    static int life;
    static int score;
    static boolean isGiven = false;
    static boolean isPause = true;
    static void newGame(View view) {
        life = 3;
        score = 0;
        isPause = true;
        map = new Map();
        map.loadMap(view.getResources().openRawResource(R.raw.given));
        //set map images
        //set bean images
        //set enemy images
        //set hero images
    }

    static void judge() {
        for (Enemy enemy: Enemy.enemies) {
            if (enemy.sleep) continue;
            if ((enemy.x - hero.x) * (enemy.x - hero.x) +
                    (enemy.y - hero.y) * (enemy.y - hero.y) < Map.side * Map.side / 2) {
                if (enemy.type < 2) {
                    life --;
                    if (life > 0) {
                        for (Enemy enemy1: Enemy.enemies) enemy1.backToLife();
                        hero.backToLife();
                    }
                }
                else {
                    enemy.backToLife();
                    score += 100;
                }
            }
        }
        if (life <= 0) {
            for (Enemy enemy1: Enemy.enemies) enemy1.sleep = true;
            hero.sleep = true;
        }
    }
    
    static void eat() {
        boolean allEat = true;
        for (Bean bean: Bean.beans) {
            if ((!bean.eaten) && (bean.x - hero.x) * (bean.x - hero.x) +
                    (bean.y - hero.y) * (bean.y - hero.y) < Map.side * Map.side / 4) {
                bean.eaten = true;
                //delete bean images
                score += 10;
                if (bean.type == Bean.big) {
                    bean.strong();
                    score += 90;
                }
            }
            if (!bean.eaten) allEat = false;
        }
        if (allEat) {
            score += 300 * life;
            for (Enemy enemy1: Enemy.enemies) enemy1.sleep = true;
            hero.sleep = true;
        }
    }

    static void error() {
        System.out.println("Something worse happened...");
    }

    static void gamePause() {
        if (isPause) {
            isPause = false;
        }
        else {
            isPause = true;
        }
    }

}
