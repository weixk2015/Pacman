package com.pj2.pacman;

import android.app.Activity;
import android.os.Bundle;

import java.io.IOException;

/**
 * Created by xk on 2016/12/24.
 */

public class GameActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //显示自定义的SurfaceView 视图
        try {
            setContentView(new GameView(this));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
