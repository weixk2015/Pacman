package com.pj2.pacman;

import java.util.ArrayList;

class Bean {
    static ArrayList<Bean> beans = new ArrayList<>();
    final static int small = 2;
    final static int big = 3;
    int x;
    int y;
    int type;
    boolean eaten;
    //Image[] icon;

    Bean(int x, int y, int newType) {
        this.x = x;
        this.y = y;
        type = newType;
        eaten = false;
        //icon = new Image[9];
        for (int i = 0; i < 9; i++) {
            //icon.setX(x);
            //icon.setY(y);
        }
        beans.add(this);
    }

    void strong() {
        for (Enemy enemy: Enemy.enemies) {
            enemy.time = Enemy.weakTime;
            if (enemy.type < 2) enemy.type += 3;
            enemy.speed = Enemy.weakSpeed;
            enemy.setImage();
        }
    }
}