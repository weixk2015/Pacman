package com.pj2.pacman;

import java.util.ArrayList;
import java.util.Random;

class Enemy extends Creature {
    static ArrayList<Enemy> enemies = new ArrayList<>();
    final static int slowType = 0;
    final static int fastType = 1;
    final static int slowSpeed = 2;
    final static int fastSpeed = 4;
    final static int weakSpeed = 1;
    final static int blindTime = 66 * 3;
    final static int weakTime = 66 * 5 + 6;
    final static int warnTime = 66 * 2;
    int type;
    private int newDir;
    private boolean cantMove = false;
    int speed;
    int time;

    Enemy(int x, int y, int newType) {
        super(x, y);
        type = newType;
        speed = type == slowType ? slowSpeed: fastSpeed;
        time = blindTime;
        setImage();
        direction = randomDir();
        newDir = direction;
        enemies.add(this);
    }

    @Override
    void setImage() {
    }

    @Override
    void backToLife() {
        super.backToLife();
        if (type > 2) type -= 3;
        speed = type == slowType ? slowSpeed: fastSpeed;
        setImage();
        direction = randomDir();
        newDir = direction;
        time = blindTime;
    }

    @Override
    void move() {
        if (sleep) return;
        if (cantMove) return;
        /**
        if (time >= 0) {
            if (time < warnTime && time > 0 && type > 2) {
                if (time % 20 == 0) {
                    if (x % 4 != 0) setPos(4 * (x / 4), y);
                    if (y % 4 != 0) setPos(x, 4 * (y / 4));
                    type -= 3;
                    setImage();
                    type += 3;
                } else if (time % 20 == 10) setImage();
            } else if (time == 0 && type > 2) {
                type -= 3;
                speed = type == 0 ? fastSpeed : slowSpeed;
                setImage();
            }
            time--;
        }
        if (x % Map.side == 0 && y % Map.side == 0) {
            if (time < 0 && x == Pacman.hero.x && y > Pacman.hero.y && canMove(0, x, y)) newDir = 0;
            else if (time < 0 && x == Pacman.hero.x && y < Pacman.hero.y && canMove(2, x, y))
                newDir = 2;
            else if (time < 0 && y == Pacman.hero.y && x > Pacman.hero.x && canMove(3, x, y))
                newDir = 3;
            else if (time < 0 && y == Pacman.hero.y && x < Pacman.hero.x && canMove(1, x, y))
                newDir = 1;
            else if (type > 2 && x == Pacman.hero.x && y > Pacman.hero.y && canMove(2, x, y))
                newDir = 2;
            else if (type > 2 && x == Pacman.hero.x && y < Pacman.hero.y && canMove(0, x, y))
                newDir = 0;
            else if (type > 2 && y == Pacman.hero.y && x > Pacman.hero.x && canMove(1, x, y))
                newDir = 1;
            else if (type > 2 && y == Pacman.hero.y && x < Pacman.hero.x && canMove(3, x, y))
                newDir = 3;
            else if (canMove((direction + 1) % 4, x, y) || canMove((direction + 3) % 4, x, y)) {
                do {
                    newDir = randomDir();
                } while (!canMove(newDir, x, y) || newDir == (direction + 2) % 4);
            }
            else if (canMove(direction, x, y)) newDir = direction;
            else if (canMove((direction + 2) % 4, x, y)) newDir = (direction + 2) % 4;
            else {
                cantMove = true;
                return;
            }
        }
        if (newDir != direction) {
            direction = newDir;
            setImage();
        }
        setPos(outOfIndex(x + speed * DIR_X[direction], 0), outOfIndex(y + speed * DIR_Y[direction], 1));
         **/
    }

    private int randomDir() {
        return (new Random()).nextInt(4);
    }

}
